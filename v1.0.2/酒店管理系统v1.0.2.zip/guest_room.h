#pragma once
#include <string>
#include <map>
#include <fstream>
#include <sstream>
using namespace std;
//����enum ROOM_STATEö�����ͣ���ʾ�ͷ�״̬�����С���ס
enum class ROOM_STATE
{
    FREE = 0,
    CHECK_IN =1,
};
//�ͷ���
class GuestRoom
{
public:
    GuestRoom()=default;
    GuestRoom(string,int,int,int,ROOM_STATE);
    string generate_number();
    string show_state();
    static bool save_data(const map<string, GuestRoom>& room_list);
    map<string,GuestRoom> read_data();
public:
    const std::string& get_number() const;
    const std::string& get_name() const;
    int get_price() const;
    int get_area() const;
    int get_bed_number() const;
    void set_state();
    void set_number(const std::string& number);
    ROOM_STATE get_state() const;
private:
    string m_number;
    string m_name;
    int m_price;
    int m_bed_number;
	int m_area;
    enum ROOM_STATE m_state;
};
